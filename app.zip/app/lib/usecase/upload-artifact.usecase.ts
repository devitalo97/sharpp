export class UploadArtifactUsecase {
  execute() {}
}
