"use client";
import Image from "next/image";
import type React from "react";

import { useState } from "react";
import {
  ImageIcon,
  X,
  FileIcon,
  VideoIcon,
  FileTextIcon,
  TagIcon,
  InfoIcon,
  Eye,
  Download,
  Copy,
  Check,
} from "lucide-react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import type { Artifact } from "@/app/lib/backend/domain/entity/artifact.entity";
import { ArtifactDetailModal } from "../modal/artifact.modal";
import { toast } from "sonner";

interface ArtifactListProps {
  artifacts: Artifact[];
}

interface CopyableValueProps {
  value: string;
  label?: string;
  className?: string;
  showIcon?: boolean;
}

function CopyableValue({
  value,
  label,
  className = "",
  showIcon = true,
}: CopyableValueProps) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async (e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      await navigator.clipboard.writeText(value);
      setCopied(true);
      toast.success(`${label ? `${label} ` : ""}copied to clipboard`);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      toast.error("Failed to copy to clipboard");
    }
  };

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <span
            className={`cursor-pointer hover:bg-muted/50 rounded px-1 py-0.5 transition-colors inline-flex items-center gap-1 ${className}`}
            onClick={handleCopy}
            title={`Click to copy: ${value}`}
          >
            {value}
            {showIcon && (
              <span className="opacity-0 group-hover:opacity-100 transition-opacity">
                {copied ? (
                  <Check className="h-3 w-3 text-green-600" />
                ) : (
                  <Copy className="h-3 w-3 text-muted-foreground" />
                )}
              </span>
            )}
          </span>
        </TooltipTrigger>
        <TooltipContent>
          <p>Click to copy {label ? label.toLowerCase() : "value"}</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

const getTypeIcon = (type: Artifact["type"]) => {
  switch (type) {
    case "image":
      return <ImageIcon className="h-4 w-4" />;
    case "video":
      return <VideoIcon className="h-4 w-4" />;
    case "pdf":
      return <FileTextIcon className="h-4 w-4" />;
    default:
      return <FileIcon className="h-4 w-4" />;
  }
};

const getTypeColor = (type: Artifact["type"]) => {
  switch (type) {
    case "image":
      return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300";
    case "video":
      return "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300";
    case "pdf":
      return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300";
    default:
      return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300";
  }
};

const formatFileSize = (bytes?: number) => {
  if (!bytes) return "Unknown size";
  const sizes = ["Bytes", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  return `${Math.round((bytes / Math.pow(1024, i)) * 100) / 100} ${sizes[i]}`;
};

const formatDate = (date: Date) => {
  return new Intl.DateTimeFormat("pt-BR", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  }).format(date);
};

export function ArtifactList({ artifacts }: ArtifactListProps) {
  const [selectedArtifact, setSelectedArtifact] = useState<Artifact | null>(
    null
  );
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleDelete = (artifactId: string) => {};

  const handleViewDetails = (artifact: Artifact) => {
    setSelectedArtifact(artifact);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setSelectedArtifact(null);
  };

  const handleDownload = (artifact: Artifact) => {
    const filename = artifact.title || artifact.key.split("/").pop()!;
    // navegando para a sua própria rota, tudo é same-origin:
    window.location.href = `/api/artifact/download?key=${
      artifact.key
    }&filename=${encodeURIComponent(filename)}`;
  };

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ImageIcon className="h-5 w-5" />
            Gallery ({artifacts.length}{" "}
            {artifacts.length === 1 ? "item" : "items"})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {artifacts.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <ImageIcon className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>No artifacts uploaded yet</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {artifacts.map((artifact) => {
                const fileName = artifact.key.split("/").pop() || artifact.id;
                const displayTitle = artifact.title || fileName;
                const src = artifact.signed_url || "/placeholder.svg";

                return (
                  <Card
                    key={artifact.id}
                    className="group relative overflow-hidden"
                  >
                    {/* Header with type and action buttons */}
                    <div className="absolute top-2 left-2 right-2 flex justify-between items-start z-10">
                      <Badge
                        className={`${getTypeColor(artifact.type)} border-0`}
                      >
                        {getTypeIcon(artifact.type)}
                        <span className="ml-1 capitalize">{artifact.type}</span>
                      </Badge>

                      <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <Button
                          variant="secondary"
                          size="icon"
                          className="h-8 w-8"
                          onClick={() => handleViewDetails(artifact)}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>

                        <Button
                          variant="secondary"
                          size="icon"
                          className="h-8 w-8"
                          onClick={() => handleDownload(artifact)}
                        >
                          <Download className="h-4 w-4" />
                        </Button>

                        <Button
                          variant="destructive"
                          size="icon"
                          className="h-8 w-8"
                          onClick={() => handleDelete(artifact.id)}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>

                    {/* Media Preview */}
                    <div
                      className="aspect-video overflow-hidden bg-muted cursor-pointer"
                      onClick={() => handleViewDetails(artifact)}
                    >
                      {artifact.type === "image" ? (
                        <Image
                          src={src || "/placeholder.svg"}
                          alt={displayTitle}
                          width={400}
                          height={300}
                          className="h-full w-full object-cover transition-transform group-hover:scale-105"
                        />
                      ) : (
                        <div className="h-full w-full flex items-center justify-center bg-muted">
                          <div className="text-center">
                            {getTypeIcon(artifact.type)}
                            <p className="text-sm text-muted-foreground mt-2">
                              {artifact.type.toUpperCase()} File
                            </p>
                          </div>
                        </div>
                      )}
                    </div>

                    <CardContent className="p-4 space-y-3">
                      {/* Title and Description */}
                      <div>
                        <h3
                          className="font-semibold text-sm line-clamp-2 cursor-pointer hover:text-primary"
                          title={displayTitle}
                          onClick={() => handleViewDetails(artifact)}
                        >
                          {displayTitle}
                        </h3>
                        {artifact.description && (
                          <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                            {artifact.description}
                          </p>
                        )}
                      </div>

                      {/* Tags */}
                      {artifact.tags && artifact.tags.length > 0 && (
                        <div className="flex flex-wrap gap-1">
                          {artifact.tags.slice(0, 3).map((tag, index) => (
                            <Badge
                              key={index}
                              variant="secondary"
                              className="text-xs group/tag"
                            >
                              <TagIcon className="h-3 w-3 mr-1" />
                              <CopyableValue
                                value={tag}
                                label="Tag"
                                showIcon={false}
                              />
                            </Badge>
                          ))}
                          {artifact.tags.length > 3 && (
                            <TooltipProvider>
                              <Tooltip>
                                <TooltipTrigger>
                                  <Badge variant="outline" className="text-xs">
                                    +{artifact.tags.length - 3}
                                  </Badge>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <div className="space-y-1">
                                    {artifact.tags
                                      .slice(3)
                                      .map((tag, index) => (
                                        <div key={index} className="text-xs">
                                          <CopyableValue
                                            value={tag}
                                            label="Tag"
                                            showIcon={false}
                                          />
                                        </div>
                                      ))}
                                  </div>
                                </TooltipContent>
                              </Tooltip>
                            </TooltipProvider>
                          )}
                        </div>
                      )}

                      <Separator />

                      {/* Metadata */}
                      <div className="space-y-2">
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <InfoIcon className="h-3 w-3" />
                          <span>Details</span>
                        </div>

                        <div className="grid grid-cols-2 gap-2 text-xs">
                          {artifact.metadata?.size_bytes && (
                            <div className="group/detail">
                              <span className="text-muted-foreground">
                                Size:
                              </span>
                              <span className="ml-1">
                                <CopyableValue
                                  value={formatFileSize(
                                    artifact.metadata.size_bytes
                                  )}
                                  label="File size"
                                  className="text-xs"
                                />
                              </span>
                            </div>
                          )}

                          {artifact.metadata?.width &&
                            artifact.metadata?.height && (
                              <div className="group/detail">
                                <span className="text-muted-foreground">
                                  Dimensions:
                                </span>
                                <span className="ml-1">
                                  <CopyableValue
                                    value={`${artifact.metadata.width}×${artifact.metadata.height}`}
                                    label="Dimensions"
                                    className="text-xs"
                                  />
                                </span>
                              </div>
                            )}

                          {artifact.metadata?.format && (
                            <div className="group/detail">
                              <span className="text-muted-foreground">
                                Format:
                              </span>
                              <span className="ml-1">
                                <CopyableValue
                                  value={artifact.metadata.format.toUpperCase()}
                                  label="Format"
                                  className="text-xs"
                                />
                              </span>
                            </div>
                          )}

                          <div className="group/detail">
                            <span className="text-muted-foreground">
                              Created:
                            </span>
                            <span className="ml-1">
                              <CopyableValue
                                value={formatDate(artifact.created_at)}
                                label="Creation date"
                                className="text-xs"
                              />
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Custom Attributes */}
                      {artifact.attributes &&
                        artifact.attributes.length > 0 && (
                          <>
                            <Separator />
                            <div className="space-y-2">
                              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                                <TagIcon className="h-3 w-3" />
                                <span>Attributes</span>
                              </div>

                              <div className="space-y-1">
                                {artifact.attributes
                                  .slice(0, 3)
                                  .map((attr, index) => (
                                    <div
                                      key={index}
                                      className="flex justify-between text-xs group/attr"
                                    >
                                      <span className="text-muted-foreground truncate">
                                        {attr.key}:
                                      </span>
                                      <span
                                        className="ml-2 truncate"
                                        title={attr.value}
                                      >
                                        <CopyableValue
                                          value={attr.value}
                                          label={attr.key}
                                          className="text-xs max-w-[120px] truncate"
                                        />
                                      </span>
                                    </div>
                                  ))}

                                {artifact.attributes.length > 3 && (
                                  <TooltipProvider>
                                    <Tooltip>
                                      <TooltipTrigger asChild>
                                        <Button
                                          variant="ghost"
                                          size="sm"
                                          className="h-auto p-0 text-xs text-muted-foreground"
                                        >
                                          +{artifact.attributes.length - 3} more
                                          attributes
                                        </Button>
                                      </TooltipTrigger>
                                      <TooltipContent>
                                        <div className="space-y-1 max-w-xs">
                                          {artifact.attributes
                                            .slice(3)
                                            .map((attr, index) => (
                                              <div
                                                key={index}
                                                className="flex justify-between text-xs"
                                              >
                                                <span className="text-muted-foreground">
                                                  {attr.key}:
                                                </span>
                                                <span className="ml-2">
                                                  <CopyableValue
                                                    value={attr.value}
                                                    label={attr.key}
                                                    className="text-xs"
                                                    showIcon={false}
                                                  />
                                                </span>
                                              </div>
                                            ))}
                                        </div>
                                      </TooltipContent>
                                    </Tooltip>
                                  </TooltipProvider>
                                )}
                              </div>
                            </div>
                          </>
                        )}
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      <ArtifactDetailModal
        artifact={selectedArtifact}
        isOpen={isModalOpen}
        onClose={handleCloseModal}
      />
    </>
  );
}
