import { ContentUpsertForm } from "@/app/lib/frontend/components/form/upsert.content.form";
import { PageHeader } from "@/app/lib/frontend/components/page-header";

interface PageProps {
  params: {
    community_id: string;
  };
}

export default async function Page({ params }: PageProps) {
  const { community_id } = await params;

  return (
    <div className="grid gap-4">
      <PageHeader
        title="Criar link de conteúdo"
        description="Faça upload de múltiplas mídias digitais e organize seu conteúdo com
            metadados personalizados."
        breadcrumbs={[
          { label: "Dashboard", href: "/dashboard" },
          { label: "Minhas Comunidades", href: "/community" },
          { label: "Minha comunidade", href: "/community/1" },
          { label: "Meus conteúdos", href: "/community/1/content" },
          { label: "Novo conteúdo" },
        ]}
      />
      <ContentUpsertForm communityId={community_id} mode="create" />
    </div>
  );
}
